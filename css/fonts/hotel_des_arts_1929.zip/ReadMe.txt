=== Hi, thanks for downloading my font ! ===

I’m Johan, 17 yo. from France. 

Feel free to use this font for your personal projects and don’t hesitate to show me your creations featuring this font, I would really appreciate ! 

Please consider making a small donation if you enjoyed my work. 

If you need to contact me for any reason, send me an e-mail :

johan.chalibert@icloud.com

